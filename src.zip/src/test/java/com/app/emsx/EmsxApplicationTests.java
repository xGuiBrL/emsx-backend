package com.app.emsx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsxApplicationTests {

    @Test
    void contextLoads() {
    }

}
