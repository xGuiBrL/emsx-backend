package com.app.emsx.entities;

public enum Role {
    ADMIN,
    USER
}
